# Introduction
This is a Java project, which use Maven to manage dependency.

# How to run
fill your EcoFlow Open Platform accessKey and secretKey to com.ecoflow.iot.open.Main class,then run the main method

